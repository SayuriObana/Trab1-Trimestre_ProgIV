﻿using System;
using System.Windows;

namespace MenuPrincipal
{
    /// <summary>
    /// Lógica interna para Exercicio1.xaml
    /// </summary>
    public partial class Exercicio1 : Window
    {
        public Exercicio1()
        {
            InitializeComponent();
        }

        private void Somar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int numero1 = int.Parse(txtNumero1.Text);
                int numero2 = int.Parse(txtNumero2.Text);
                int resultado = numero1 + numero2;

                MessageBox.Show($"A soma é: {resultado}", "Resultado", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch
            {
                MessageBox.Show("Por favor, digite dois números inteiros válidos.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
