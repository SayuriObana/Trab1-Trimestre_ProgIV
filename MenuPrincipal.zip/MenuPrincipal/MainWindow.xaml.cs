﻿using System;
using System.Windows;

namespace MenuPrincipal
{
    /// <summary>
    /// Interação lógica para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AbrirExercicio1_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio1();
            janela.Show();
        }

        private void AbrirExercicio2_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio2();
            janela.Show();
        }

        private void AbrirExercicio3_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio3();
            janela.Show();
        }

        private void AbrirExercicio4_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio4();
            janela.Show();
        }

        private void AbrirExercicio5_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio5();
            janela.Show();
        }

        private void AbrirExercicio6_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio6();
            janela.Show();
        }
        private void AbrirExercicio7_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio7();
            janela.Show();
        }
        private void AbrirExercicio8_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio8();
            janela.Show();
        }
        private void AbrirExercicio9_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio9();
            janela.Show();
        }
        private void AbrirExercicio10_Click(object sender, RoutedEventArgs e)
        {
            var janela = new Exercicio10();
            janela.Show();
        }

    }
}
